g++ -std=c++11 -pthread -o ejecutable ejemplo09-integral.cpp
./ejecutable