# SCD
Asignatura de sistemas concurrentes y distribuidos de la UGR
Una asignatura con alto chance de suspenso because teacher's fault. By the way muy ez, gg, viva erasmus :)
